export const sales = [
  {
    orderId: 10248,
    region: "North America",
    country: "United States",
    city: "New York",
    amount: 1740,
    date: "2013/01/06",
  },
  {
    orderId: 10249,
    region: "North America",
    country: "United States",
    city: "Los Angeles",
    amount: 850,
    date: "2013/01/13",
  },
  {
    orderId: 10250,
    region: "North America",
    country: "United States",
    city: "Denver",
    amount: 2235,
    date: "2013/01/07",
  },
  {
    orderId: 10251,
    region: "North America",
    country: "Canada",
    city: "Vancouver",
    amount: 1965,
    date: "2013/01/03",
  },
];
