let baseUrl = "https://secmark-ms-tradewebapi.azurewebsites.net/api/";

export const BACKEND_BASE_URL = baseUrl;
