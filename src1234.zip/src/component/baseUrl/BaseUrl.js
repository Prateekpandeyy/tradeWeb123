// export const baseUrl = "http://20.204.151.106:5019/api"
export const baseUrl = "https://secmark-ms-tradewebapi.azurewebsites.net/api";
