export const sidemenu = [
  {
    id: 1,
    title: "Personal Information",
    link: "/tradeweb/profile",
  },
  {
    id: 2,
    title: "Nominees",
    link: "/tradeweb/nominee",
  },
  {
    id: 3,
    title: "Bank",
    link: "/tradeweb/bank",
  },
  {
    id: 4,
    title: "Demat",
    link: "/tradeweb/demat",
  },
  {
    id: 5,
    title: "Documents",
    link: "/tradeweb/documnets",
  },
  {
    id: 6,
    title: "Commodity Declation",
    link: "/tradeweb/commodity",
  },
  {
    id: 7,
    title: "Account Closure",
    link: "/tradeweb/accountclosure",
  },
  {
    id: 8,
    title: "Logout",
    link: "/tradeweb/accountclosure",
  },
];
