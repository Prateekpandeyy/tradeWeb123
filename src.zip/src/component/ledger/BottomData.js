const BottomData = [
    {
       id : "1",
       data : "292929kdkd",
       exchange : "dkslj-2299",
       particulaes : "This is one of the best",
       debit : "8000",
       creadit : "292929",
       balance : "1999191"
    },
    {
        id : "2",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     },
     {
        id : "3",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     },
     {
        id : "4",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     },
     {
        id : "5",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     },
     {
        id : "6",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     },
     {
        id : "7",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     },
     {
        id : "8",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     },
     {
        id : "9",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     },
     {
        id : "10",
        data : "292929kdkd",
        exchange : "dkslj-2299",
        particulaes : "This is one of the best",
        debit : "8000",
        creadit : "292929",
        balance : "1999191"
     }
]
export default BottomData;