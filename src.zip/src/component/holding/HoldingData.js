const HoldingData = [
    {
        id : 1,
        stack : "IDEA",
        Quantity : 100,
        Current : 120,
        CurrentValue : 12000,
        NetProfile : 2000,
        buyTxt : "Buy",
        sellTxt : "Sell"
    },
    {
        id : 2,
        stack : "IDEA",
        Quantity : 100,
        Current : 120,
        CurrentValue : 12000,
        NetProfile : 2000,
        buyTxt : "Buy",
        sellTxt : "Sell"
    },
    {
        id : 3,
        stack : "IDEA",
        Quantity : 100,
        Current : 120,
        CurrentValue : 12000,
        NetProfile : 2000,
        buyTxt : "Buy",
        sellTxt : "Sell"
    },
    {
        id : 4,
        stack : "IDEA",
        Quantity : 100,
        Current : 120,
        CurrentValue : 12000,
        NetProfile : 2000,
        buyTxt : "Buy",
        sellTxt : "Sell"
    },
    {
        id : 5,
        stack : "IDEA",
        Quantity : 100,
        Current : 120,
        CurrentValue : 12000,
        NetProfile : 2000,
        buyTxt : "Buy",
        sellTxt : "Sell"
    },
    {
        id : 6,
        stack : "IDEA",
        Quantity : 100,
        Current : 120,
        CurrentValue : 12000,
        NetProfile : 2000,
        buyTxt : "Buy",
        sellTxt : "Sell"
    }
]
export default HoldingData;