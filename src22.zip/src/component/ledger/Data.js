const rowData = [
    {
        id: "1",
        openingBalance : "3000", 
        closeIngBalance : "8000", 
        debit : "40000",
        creadit : "8000",
        balance : "60000"
    },
    {
        id: "2",
        openingBalance : "4000", 
        closeIngBalance : "7000",
        debit : "40000",
        creadit : "8000",
        balance : "60000" 
    },
    
   
   
]
export default rowData;